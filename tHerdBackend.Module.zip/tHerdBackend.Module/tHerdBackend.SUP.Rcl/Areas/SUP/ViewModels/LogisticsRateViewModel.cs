﻿namespace tHerdBackend.SUP.Rcl.Areas.SUP.ViewModels
{
	public class LogisticsRateViewModel
	{
		/// <summary>
		/// 主鍵
		/// </summary>
		public int LogisticsRateId { get; set; }

		/// <summary>
		/// 關聯物流Id
		/// </summary>
		public int LogisticsId { get; set; }

		/// <summary>
		/// 最小重量 (kg)
		/// </summary>
		public decimal WeightMin { get; set; }

		/// <summary>
		/// 最大重量 (kg)，NULL=無限大
		/// </summary>
		public decimal? WeightMax { get; set; }

		/// <summary>
		/// 運費
		/// </summary>
		public decimal ShippingFee { get; set; }

		/// <summary>
		/// 是否啟用
		/// </summary>
		public bool IsActive { get; set; }

		/// <summary>
		/// 異動人員
		/// </summary>
		public int? Reviser { get; set; }

		/// <summary>
		/// 異動時間
		/// </summary>
		public DateTime? RevisedDate { get; set; }
	}
}