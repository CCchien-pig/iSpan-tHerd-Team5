using Microsoft.AspNetCore.Mvc.RazorPages;

namespace tHerdBackend.PROD.Rcl.Areas.PROD.Views.UploadTest
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
