using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace tHerdBackend.SYS.Rcl.Areas.SYS.Views.Images
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
