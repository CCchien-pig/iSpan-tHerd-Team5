using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace tHerdBackend.ORD.Rcl.Areas.ORD.Views.Rma
{
    public class _RmaDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
