using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace tHerdBackend.ORD.Rcl.Areas.ORD.Views.Orders
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
