﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tHerdBackend.CNT.Rcl.Areas.CNT.ViewModels
{
	public class CtaBlock
	{
		public required string Url { get; set; }
		public required string Text { get; set; }
	}
}
