﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tHerdBackend.CNT.Rcl.Areas.CNT.ViewModels
{
	public class UpdateTimeVM
	{
		public int Id { get; set; }
		public DateTime ScheduledDate { get; set; }
	}
}
