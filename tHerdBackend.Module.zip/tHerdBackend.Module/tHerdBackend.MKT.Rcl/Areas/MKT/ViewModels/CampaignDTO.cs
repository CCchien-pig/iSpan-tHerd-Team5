﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tHerdBackend.MKT.Rcl.Areas.MKT.ViewModels
{
    public class CampaignDTO
    {
        public int CampaignId { get; set; }
        public string CampaignName { get; set; }
    }

}
