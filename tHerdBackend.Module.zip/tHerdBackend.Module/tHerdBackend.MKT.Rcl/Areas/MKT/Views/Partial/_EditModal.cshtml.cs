using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace tHerdBackend.MKT.Rcl.Areas.MKT.Views.Partial
{
    public class _EditModalModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
