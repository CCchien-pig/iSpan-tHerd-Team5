using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace tHerdBackend.MKT.Rcl.Areas.MKT.Views.Ads
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
